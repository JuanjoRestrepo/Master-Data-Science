# **paqueteMETODOS**

<br/>
<center>
<img src="inst/figures/Logo_paqueteMETODOS.png" alt=" " style="width:20%;">
</center>

## **Introducción**

El presente contiene elemetos de apoyo al curso **Métodos Estadística para la toma de decisiones**

Contiene :

* Bases de datos
* Funciones
* Tutoriales

<br/><br/>

## **Instalación**

```
install.packages("devtools")
devtools::install_github("dgonxalex80/paqueteMETODOS")
library(paqueteMETODOS)
```



<br/><br/>

## **Actualizaciones**

No se han realizado actualizaciones

La versión actual del paquete es : 0.1.0
